from __future__ import annotations

from fruit_of_life.contracts.executive import CandidateOption, DecisionContext, FinalDecision, RequestInterpretation, ScoredOption
from fruit_of_life.policies.decision_policy import apply_hard_stops


def synthesize_decision(
    options: list[CandidateOption],
    context: DecisionContext,
    interpretation: RequestInterpretation,
    opportunity: dict[str, float],
    risk: dict[str, float],
) -> FinalDecision:
    scored_options: list[ScoredOption] = []
    for option in options:
        alignment = 0.85 if option.option_id == "opt_2" else 0.55
        feasibility = 0.9 if option.option_id in {"opt_2", "opt_3"} else 0.45
        scored_options.append(
            ScoredOption(
                option=option,
                opportunity_score=opportunity.get(option.option_id, 0.5),
                risk_score=risk.get(option.option_id, 0.5),
                alignment_score=alignment,
                feasibility_score=feasibility,
            )
        )
    scored_options = apply_hard_stops(scored_options, context, interpretation)
    viable = [item for item in scored_options if not item.blocked]
    viable.sort(key=lambda item: item.final_score(), reverse=True)
    chosen = viable[0] if viable else scored_options[0]
    alternatives = [
        {
            "option_id": item.option.option_id,
            "title": item.option.title,
            "summary": item.option.summary,
            "final_score": round(item.final_score(), 4),
        }
        for item in viable[1:]
    ]
    return FinalDecision(
        title=chosen.option.title,
        summary=(
            "This option best balances your goals, current cash flow, and financial stability."
            if interpretation.intent == "affordability_analysis"
            else chosen.option.summary
        ),
        rationale=[
            "Current fixed obligations already consume a large share of take-home pay.",
            "A cautious route fits the stated goal of financial stability.",
            "The selected option had the strongest balance of feasibility and risk control.",
        ],
        risks=[
            "high discretionary spending pressure",
            "no emergency savings",
        ] if interpretation.intent == "affordability_analysis" else ["context may be incomplete"],
        alternatives=alternatives,
        confidence=round(min(0.95, (context.context_confidence + interpretation.confidence) / 2), 2),
        next_steps=[
            "Set a trip savings target",
            "Build a starter cash reserve",
            "Review affordability in 30 to 60 days",
        ] if interpretation.intent == "affordability_analysis" else ["Review priorities", "Choose the highest-leverage next action"],
    )
