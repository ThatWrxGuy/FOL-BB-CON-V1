"""Tree of Life semantic node layer for Busy Bee."""
