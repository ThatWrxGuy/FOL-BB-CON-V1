from __future__ import annotations

from fruit_of_life.contracts.executive import DecisionContext, ExecutiveRequest


def assemble_context(request: ExecutiveRequest) -> DecisionContext:
    text = request.text.lower()
    travel_like = any(word in text for word in ["trip", "vacation", "travel", "miami"])
    profile = {"income_monthly_take_home": 4000}
    domain_data = {
        "mortgage": 1694.26,
        "car_payment": 482.80,
        "credit_card_debt": 14094.44,
        "cash_reserves": 0,
        "investment_account": 2500,
    }
    goals = ["financial_stability", "avoid_paycheck_to_paycheck"]
    constraints = []
    confidence = 0.85 if travel_like else 0.75
    return DecisionContext(
        user_id=request.user_id,
        profile=profile,
        domain_data=domain_data,
        goals=goals,
        constraints=constraints,
        context_confidence=confidence,
    )
