from __future__ import annotations

from fruit_of_life.contracts.executive import CandidateOption, DecisionContext, RequestInterpretation


def score_risk(
    options: list[CandidateOption],
    context: DecisionContext,
    interpretation: RequestInterpretation,
) -> dict[str, float]:
    scores: dict[str, float] = {}
    no_cash = context.domain_data.get("cash_reserves", 0) <= 0
    high_debt = context.domain_data.get("credit_card_debt", 0) > 10000
    for option in options:
        if option.option_id == "opt_1":
            scores[option.option_id] = 0.84 if no_cash and high_debt else 0.65
        elif option.option_id == "opt_2":
            scores[option.option_id] = 0.25
        elif option.option_id == "opt_3":
            scores[option.option_id] = 0.38
        else:
            scores[option.option_id] = 0.35
    return scores
