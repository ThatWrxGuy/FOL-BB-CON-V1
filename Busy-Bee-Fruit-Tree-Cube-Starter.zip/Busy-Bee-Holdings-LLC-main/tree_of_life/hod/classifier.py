from __future__ import annotations

from fruit_of_life.contracts.executive import DecisionContext, RequestInterpretation


def classify_request(text: str, context: DecisionContext) -> RequestInterpretation:
    lower = text.lower()
    if any(word in lower for word in ["trip", "vacation", "travel", "miami"]):
        domain = "finance"
        intent = "affordability_analysis"
        entities = {"destination": "Miami" if "miami" in lower else None, "timeframe": "next_month" if "month" in lower else None}
    elif "brief" in lower:
        domain = "executive"
        intent = "brief_request"
        entities = {}
    else:
        domain = "general"
        intent = "recommendation"
        entities = {}
    return RequestInterpretation(
        domain=domain,
        intent=intent,
        entities=entities,
        primary_nodes=["Chokmah", "Binah"],
        validation_nodes=["Chesed", "Gevurah"],
        final_node="Tiferet",
        confidence=min(0.95, max(0.6, context.context_confidence + 0.05)),
    )
