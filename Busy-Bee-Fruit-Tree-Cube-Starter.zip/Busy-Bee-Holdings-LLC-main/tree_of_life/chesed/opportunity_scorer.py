from __future__ import annotations

from fruit_of_life.contracts.executive import CandidateOption, DecisionContext


def score_opportunity(options: list[CandidateOption], context: DecisionContext) -> dict[str, float]:
    scores: dict[str, float] = {}
    for option in options:
        if option.option_id == "opt_1":
            scores[option.option_id] = 0.72
        elif option.option_id == "opt_2":
            scores[option.option_id] = 0.64
        elif option.option_id == "opt_3":
            scores[option.option_id] = 0.58
        else:
            scores[option.option_id] = 0.55
    return scores
