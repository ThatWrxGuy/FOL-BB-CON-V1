from __future__ import annotations

from fruit_of_life.config.settings import BB_ORCH_001_FLOW_ID
from fruit_of_life.contracts.executive import FinalDecision, OrchestrationResponse


def present_response(decision: FinalDecision, trace_id: str, stage_trace: list[str]) -> OrchestrationResponse:
    return OrchestrationResponse(
        flow_id=BB_ORCH_001_FLOW_ID,
        status="completed",
        decision=decision,
        trace_id=trace_id,
        stage_trace=stage_trace,
    )
