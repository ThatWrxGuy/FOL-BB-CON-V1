from __future__ import annotations

from fruit_of_life.contracts.executive import CandidateOption, DecisionContext, RequestInterpretation


def generate_options(context: DecisionContext, interpretation: RequestInterpretation) -> list[CandidateOption]:
    if interpretation.intent == "affordability_analysis":
        return [
            CandidateOption("opt_1", "Take trip with strict budget cap", "Proceed only if total spend stays under a defined threshold.", {"trip_budget": 1200}),
            CandidateOption("opt_2", "Delay 60 days and build reserve", "Reduce financial pressure before discretionary travel.", {"delay_days": 60, "target_cash_buffer": 1000}),
            CandidateOption("opt_3", "Replace with lower-cost local trip", "Preserve enjoyment while reducing cost.", {"trip_budget": 400}),
        ]
    return [
        CandidateOption("opt_1", "Prioritize the highest-impact next step", "Focus effort where leverage is greatest."),
        CandidateOption("opt_2", "Stabilize current systems first", "Reduce risk before expanding scope."),
    ]
