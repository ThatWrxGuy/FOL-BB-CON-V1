from __future__ import annotations

from fruit_of_life.contracts.executive import CandidateOption, DecisionContext


def structure_options(options: list[CandidateOption], context: DecisionContext) -> list[CandidateOption]:
    for option in options:
        option.assumptions.setdefault("income_reference", context.profile.get("income_monthly_take_home"))
        option.assumptions.setdefault("debt_reference", context.domain_data.get("credit_card_debt"))
    return options
