from __future__ import annotations

from fruit_of_life.contracts.executive import ExecutiveRequest
from fruit_of_life.events.models import NodeEvent
from fruit_of_life.utils.ids import new_trace_id
from tree_of_life.binah.structurer import structure_options
from tree_of_life.chesed.opportunity_scorer import score_opportunity
from tree_of_life.chokmah.option_generator import generate_options
from tree_of_life.gevurah.risk_scorer import score_risk
from tree_of_life.hod.classifier import classify_request
from tree_of_life.malkuth.presenter import present_response
from tree_of_life.tiferet.synthesizer import synthesize_decision
from tree_of_life.yesod.context_service import assemble_context


def run_bb_orch_001(request: ExecutiveRequest) -> dict:
    trace_id = new_trace_id()
    stage_trace: list[str] = []

    stage_trace.append("Malkuth:intake")
    _ = NodeEvent("Malkuth", "Yesod", "request.received", request.to_dict(), trace_id)

    context = assemble_context(request)
    stage_trace.append("Yesod:context.assembled")

    interpretation = classify_request(request.text, context)
    stage_trace.append("Hod:intent.classified")

    options = generate_options(context, interpretation)
    stage_trace.append("Chokmah:options.generated")

    structured = structure_options(options, context)
    stage_trace.append("Binah:options.structured")

    opportunity = score_opportunity(structured, context)
    stage_trace.append("Chesed:opportunity.scored")

    risk = score_risk(structured, context, interpretation)
    stage_trace.append("Gevurah:risk.scored")

    decision = synthesize_decision(structured, context, interpretation, opportunity, risk)
    stage_trace.append("Tiferet:decision.synthesized")

    response = present_response(decision, trace_id, stage_trace)
    stage_trace.append("Malkuth:response.ready")

    payload = response.to_dict()
    payload["input"] = request.to_dict()
    payload["context"] = context.to_dict()
    payload["interpretation"] = interpretation.to_dict()
    payload["options"] = [option.to_dict() for option in structured]
    payload["opportunity_scores"] = opportunity
    payload["risk_scores"] = risk
    payload["topology_route"] = [
        "Malkuth",
        "Yesod",
        "Hod",
        "Chokmah",
        "Binah",
        "Chesed",
        "Gevurah",
        "Tiferet",
        "Malkuth",
    ]
    payload["stage_trace"] = stage_trace
    return payload
