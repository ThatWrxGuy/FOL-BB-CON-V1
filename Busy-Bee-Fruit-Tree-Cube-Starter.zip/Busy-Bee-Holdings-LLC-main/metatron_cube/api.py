from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from fruit_of_life.contracts.executive import ExecutiveRequest
from .bb_orch_001 import run_bb_orch_001
from .orchestration import MetatronOrchestrator

router = APIRouter(prefix="/metatron", tags=["metatron-cube"])
orchestrator = MetatronOrchestrator()


class LegacyMetatronRunRequest(BaseModel):
    input: str
    domain: Optional[str] = None


class FlowInput(BaseModel):
    text: str = Field(..., min_length=1)


class MetatronFlowRequest(BaseModel):
    flow_id: str = "BB-ORCH-001"
    user_id: str = "demo-user"
    request_id: Optional[str] = None
    channel: str = "api"
    input: FlowInput
    metadata: Optional[dict[str, Any]] = None


@router.get("/health")
def health() -> dict:
    return {"status": "ok", "engine": "metatron-cube-overlay", "version": "0.2.0"}


@router.get("/topology")
def topology() -> dict:
    base = orchestrator.topology()
    base["fruit_layer"] = {
        "packages": ["contracts", "events", "policies", "scoring", "utils", "config"],
    }
    base["bb_orch_001_route"] = [
        "Malkuth",
        "Yesod",
        "Hod",
        "Chokmah",
        "Binah",
        "Chesed",
        "Gevurah",
        "Tiferet",
        "Malkuth",
    ]
    return base


@router.post("/run")
def run_metatron(payload: dict) -> dict:
    if payload.get("flow_id") == "BB-ORCH-001":
        request = MetatronFlowRequest(**payload)
        executive_request = ExecutiveRequest(
            request_id=request.request_id or "req-bb-orch-001",
            user_id=request.user_id,
            text=request.input.text,
            channel=request.channel,
            metadata=request.metadata,
        )
        return run_bb_orch_001(executive_request)

    legacy = LegacyMetatronRunRequest(**payload)
    result = orchestrator.run(legacy.input, domain=legacy.domain)
    return {
        "run_id": result.run_id,
        "start_node": result.start_node,
        "selected_entry": result.selected_entry,
        "mesh_trace": result.mesh_trace,
        "reachable_nodes": result.reachable_nodes,
        "tree_route": result.tree_route,
        "final_output": result.final_output,
        "explanation": result.explanation,
        "confidence": result.confidence,
        "risk_score": result.risk_score,
        "metrics": result.metrics,
    }
