from __future__ import annotations

from .contracts import MeshEdge


# The Tree of Life remains the vertical path engine.
# This map adds the lateral / radial Metatron overlay around it.
MESH_EDGES: list[MeshEdge] = [
    MeshEdge("MC-01", "MetatronCore", "Keter", "entrypoint", mode="radial", bidirectional=True),
    MeshEdge("MC-02", "MetatronCore", "Tiferet", "balance-hub", mode="radial", bidirectional=True),
    MeshEdge("MC-03", "MetatronCore", "Yesod", "integration-hub", mode="radial", bidirectional=True),
    MeshEdge("MC-04", "MetatronCore", "Malkuth", "delivery-hub", mode="radial", bidirectional=True),
    MeshEdge("MC-05", "Keter", "Binah", "executive-to-structure", bidirectional=True),
    MeshEdge("MC-06", "Keter", "Chokmah", "executive-to-insight", bidirectional=True),
    MeshEdge("MC-07", "Chokmah", "Binah", "idea-to-form", bidirectional=True),
    MeshEdge("MC-08", "Chokmah", "Chesed", "expansion-lane", bidirectional=True),
    MeshEdge("MC-09", "Binah", "Gevurah", "constraint-lane", bidirectional=True),
    MeshEdge("MC-10", "Chesed", "Gevurah", "growth-vs-constraint", bidirectional=True),
    MeshEdge("MC-11", "Chesed", "Tiferet", "expansion-to-synthesis", bidirectional=True),
    MeshEdge("MC-12", "Gevurah", "Tiferet", "governance-to-synthesis", bidirectional=True),
    MeshEdge("MC-13", "Tiferet", "Netzach", "decision-to-optimization", bidirectional=True),
    MeshEdge("MC-14", "Tiferet", "Hod", "decision-to-explanation", bidirectional=True),
    MeshEdge("MC-15", "Netzach", "Hod", "execution-explanation loop", bidirectional=True),
    MeshEdge("MC-16", "Netzach", "Yesod", "execution-to-memory", bidirectional=True),
    MeshEdge("MC-17", "Hod", "Yesod", "language-to-memory", bidirectional=True),
    MeshEdge("MC-18", "Yesod", "Malkuth", "manifestation bridge", bidirectional=True),
    MeshEdge("MC-19", "Tiferet", "Yesod", "synthesis-to-bridge", bidirectional=True),
    MeshEdge("MC-20", "Hod", "Malkuth", "presentation lane", bidirectional=True),
]


class ConnectionMap:
    def __init__(self, edges: list[MeshEdge] | None = None):
        self.edges = edges or list(MESH_EDGES)
        self._adjacency: dict[str, list[MeshEdge]] = {}
        for edge in self.edges:
            self._adjacency.setdefault(edge.source, []).append(edge)
            if edge.bidirectional:
                reverse = MeshEdge(
                    edge_id=f"{edge.edge_id}R",
                    source=edge.target,
                    target=edge.source,
                    relationship=edge.relationship,
                    mode=edge.mode,
                    bidirectional=True,
                )
                self._adjacency.setdefault(reverse.source, []).append(reverse)

    def neighbors(self, node: str) -> list[str]:
        return [edge.target for edge in self._adjacency.get(node, [])]

    def describe(self) -> list[dict]:
        return [
            {
                "edge_id": edge.edge_id,
                "source": edge.source,
                "target": edge.target,
                "relationship": edge.relationship,
                "mode": edge.mode,
            }
            for edge in self.edges
        ]
