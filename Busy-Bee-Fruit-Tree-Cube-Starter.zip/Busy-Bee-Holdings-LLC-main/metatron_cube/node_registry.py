from __future__ import annotations

from tree_engine.setup import build_tree

from .contracts import MeshNodeSpec


class MetatronNodeRegistry:
    """Overlay registry that reflects the existing Tree-of-Life nodes.

    The Tree remains the canonical execution structure.
    This registry builds a mesh view around those nodes so the repo can reason
    about lateral connectivity without rewriting the original engine.
    """

    def __init__(self):
        self._specs = {}
        self._tree_executor = build_tree()
        self._register_center()
        self._register_tree_nodes()

    def _register_center(self) -> None:
        self._specs["MetatronCore"] = MeshNodeSpec(
            name="MetatronCore",
            symbolic_role="central integrator",
            system_role="topology overlay / entry routing / lateral coordination",
            source_module="metatron_cube.orchestration",
            ring="center",
        )

    def _register_tree_nodes(self) -> None:
        for name, node in self._tree_executor.node_registry.nodes.items():
            self._specs[name] = MeshNodeSpec(
                name=name,
                symbolic_role=getattr(node, "symbolic_role", ""),
                system_role=getattr(node, "system_role", ""),
                source_module=f"tree_engine.nodes.{name.lower()}",
                ring="outer",
            )

    def get(self, name: str) -> MeshNodeSpec | None:
        return self._specs.get(name)

    def list(self) -> list[MeshNodeSpec]:
        return list(self._specs.values())

    def names(self) -> list[str]:
        return list(self._specs.keys())
