from __future__ import annotations

from collections import deque

from .connection_map import ConnectionMap


class MetatronPathwayRouter:
    def __init__(self, connection_map: ConnectionMap):
        self.connection_map = connection_map

    def can_route(self, source: str, target: str) -> bool:
        return target in self.connection_map.neighbors(source)

    def shortest_path(self, source: str, target: str) -> list[str]:
        if source == target:
            return [source]

        visited = {source}
        queue = deque([(source, [source])])

        while queue:
            current, path = queue.popleft()
            for neighbor in self.connection_map.neighbors(current):
                if neighbor in visited:
                    continue
                next_path = path + [neighbor]
                if neighbor == target:
                    return next_path
                visited.add(neighbor)
                queue.append((neighbor, next_path))

        return []
