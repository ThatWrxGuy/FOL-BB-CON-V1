from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class MeshNodeSpec:
    name: str
    symbolic_role: str
    system_role: str
    source_module: str
    ring: str = "outer"


@dataclass(frozen=True)
class MeshEdge:
    edge_id: str
    source: str
    target: str
    relationship: str
    mode: str = "lateral"
    bidirectional: bool = False


@dataclass
class MeshEvent:
    event_id: str
    source: str
    target: str
    event_type: str
    payload: Dict[str, Any] = field(default_factory=dict)
    trace: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MeshRunResult:
    run_id: str
    start_node: str
    selected_entry: str
    mesh_trace: List[str]
    reachable_nodes: List[str]
    final_output: Optional[Dict[str, Any]]
    explanation: Optional[str]
    tree_route: List[str]
    confidence: float
    risk_score: float
    metrics: Dict[str, Any] = field(default_factory=dict)
