from __future__ import annotations

import uuid

from tree_engine.tree_state import TreeState
from tree_engine.setup import build_tree

from .connection_map import ConnectionMap
from .contracts import MeshRunResult
from .event_mesh import EventMesh
from .node_registry import MetatronNodeRegistry
from .pathway_router import MetatronPathwayRouter


class MetatronOrchestrator:
    """Overlay coordinator that routes through a mesh and then executes the Tree.

    This keeps the existing repo's Tree-of-Life engine as the canonical execution
    path while exposing a second architectural layer that can be extended over time.
    """

    def __init__(self):
        self.registry = MetatronNodeRegistry()
        self.connection_map = ConnectionMap()
        self.router = MetatronPathwayRouter(self.connection_map)
        self.event_mesh = EventMesh()
        self.tree_executor = build_tree()

    def _select_entry_node(self, user_input: str) -> str:
        text = user_input.lower()
        if any(word in text for word in ["risk", "safe", "policy", "governance"]):
            return "Gevurah"
        if any(word in text for word in ["explain", "describe", "summarize", "language"]):
            return "Hod"
        if any(word in text for word in ["build", "design", "create", "generate"]):
            return "Chokmah"
        if any(word in text for word in ["connect", "integrate", "memory", "sync"]):
            return "Yesod"
        return "Keter"

    def run(self, user_input: str, domain: str | None = None) -> MeshRunResult:
        run_id = str(uuid.uuid4())
        selected_entry = self._select_entry_node(user_input)
        mesh_trace = self.router.shortest_path("MetatronCore", selected_entry) or ["MetatronCore", selected_entry]

        self.event_mesh.emit(
            source="MetatronCore",
            target=selected_entry,
            event_type="mesh.entry.selected",
            payload={"run_id": run_id, "domain": domain, "user_input": user_input},
        )

        state = TreeState(run_id=run_id, user_input=user_input, domain=domain)
        tree_result = self.tree_executor.run("Keter", state)

        return MeshRunResult(
            run_id=run_id,
            start_node="MetatronCore",
            selected_entry=selected_entry,
            mesh_trace=mesh_trace,
            reachable_nodes=self.connection_map.neighbors(selected_entry),
            final_output=tree_result.final_output,
            explanation=tree_result.explanation,
            tree_route=tree_result.route_taken,
            confidence=tree_result.confidence,
            risk_score=tree_result.risk_score,
            metrics=tree_result.metadata.get("metrics", {}),
        )

    def topology(self) -> dict:
        return {
            "nodes": [
                {
                    "name": node.name,
                    "symbolic_role": node.symbolic_role,
                    "system_role": node.system_role,
                    "ring": node.ring,
                    "source_module": node.source_module,
                }
                for node in self.registry.list()
            ],
            "edges": self.connection_map.describe(),
        }
