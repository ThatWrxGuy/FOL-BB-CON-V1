from __future__ import annotations

import uuid
from collections import defaultdict
from typing import Callable

from .contracts import MeshEvent


class EventMesh:
    def __init__(self):
        self._subscribers: dict[str, list[Callable[[MeshEvent], None]]] = defaultdict(list)
        self._events: list[MeshEvent] = []

    def subscribe(self, event_type: str, handler: Callable[[MeshEvent], None]) -> None:
        self._subscribers[event_type].append(handler)

    def emit(self, source: str, target: str, event_type: str, payload: dict | None = None) -> MeshEvent:
        event = MeshEvent(
            event_id=str(uuid.uuid4()),
            source=source,
            target=target,
            event_type=event_type,
            payload=payload or {},
            trace=[source, target],
        )
        self._events.append(event)
        for handler in self._subscribers.get(event_type, []):
            handler(event)
        return event

    def recent(self, limit: int = 10) -> list[MeshEvent]:
        return self._events[-limit:]
