# Busy Bee Holdings LLC

Unified repository scaffold for the Busy Bee platform.

This package merges three layers into one GitHub-ready repository:
- Busy Bee V2 source code imported into `src/busy_bee`
- Busy Bee Holdings governance, cap table, and legal system imported into `src/busy_bee_holdings_llc`
- BOD-personal Busy-Bee-V1.3 integration targets and import directives under `imports/bod_personal_v13/`

## What is included
- Unified FastAPI entrypoint at `app/api/main.py`
- Governance engine with dual-key and board-supermajority checks
- Executive brief endpoint and bridge layer
- Cap table / ownership defaults for Busy Bee Holdings LLC
- Legal templates, proprietary license file, and third-party notices
- Source provenance preserved in `vendor/`

## Important licensing note
This repository applies a proprietary wrapper to new Busy Bee Holdings LLC materials.
Third-party and upstream source rights must still be respected. Public-source imports from BOD-personal should only be completed if you control or are authorized to use that upstream repository.

## Quickstart
```bash
pip install -e .[dev]
uvicorn app.api.main:app --reload
pytest
```


## Tree-of-Life Experimental Engine

This repository now includes a new `tree_engine/` folder that adds a graph-based Tree-of-Life orchestration layer on top of the existing Busy Bee platform. See `docs/TREE_OF_LIFE_INTEGRATION.md`.


## Metatron Cube Overlay

This repository now also includes a `metatron_cube/` overlay that wraps the existing `tree_engine/` with an explicit mesh topology, connection map, and orchestration layer.

Endpoints:
- `GET /metatron/health`
- `GET /metatron/topology`
- `POST /metatron/run`

See `docs/METATRON_CUBE_INTEGRATION.md`.


## Fruit → Tree → Cube starter

This repository now includes a starter implementation of the unified geometric architecture:

- `fruit_of_life/` for foundational primitives
- `tree_of_life/` for semantic node responsibilities
- `metatron_cube/` for orchestration and routing

Run the first orchestration flow with:

```bash
curl -X POST http://localhost:8000/metatron/run \
  -H "Content-Type: application/json" \
  -d '{
    "flow_id": "BB-ORCH-001",
    "user_id": "u_123",
    "input": {"text": "Can I afford a 4 day trip to Miami next month?"}
  }'
```
