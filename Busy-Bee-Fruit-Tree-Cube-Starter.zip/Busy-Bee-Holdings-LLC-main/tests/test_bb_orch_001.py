from fastapi import FastAPI
from fastapi.testclient import TestClient

from metatron_cube.api import router as metatron_router


def test_bb_orch_001_runs_through_metatron_endpoint():
    app = FastAPI()
    app.include_router(metatron_router)
    client = TestClient(app)
    response = client.post(
        "/metatron/run",
        json={
            "flow_id": "BB-ORCH-001",
            "user_id": "u_123",
            "input": {"text": "Can I afford a 4 day trip to Miami next month?"},
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["flow_id"] == "BB-ORCH-001"
    assert data["status"] == "completed"
    assert data["decision"]["title"]
    assert "Tiferet:decision.synthesized" in data["stage_trace"]
