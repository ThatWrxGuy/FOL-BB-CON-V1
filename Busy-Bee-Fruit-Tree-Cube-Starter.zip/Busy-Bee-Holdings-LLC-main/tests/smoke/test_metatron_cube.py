from metatron_cube.orchestration import MetatronOrchestrator


def test_metatron_topology_contains_center_and_tree_nodes():
    orchestrator = MetatronOrchestrator()
    topology = orchestrator.topology()
    node_names = {node["name"] for node in topology["nodes"]}
    assert "MetatronCore" in node_names
    assert "Keter" in node_names
    assert "Malkuth" in node_names
    assert len(topology["edges"]) >= 10


def test_metatron_run_returns_mesh_and_tree_routes():
    orchestrator = MetatronOrchestrator()
    result = orchestrator.run("Design a governance-safe dashboard for Busy Bee")
    assert result.start_node == "MetatronCore"
    assert result.selected_entry in {"Keter", "Chokmah", "Gevurah", "Hod", "Yesod"}
    assert result.mesh_trace[0] == "MetatronCore"
    assert result.tree_route[0] == "Keter"
    assert isinstance(result.metrics, dict)
