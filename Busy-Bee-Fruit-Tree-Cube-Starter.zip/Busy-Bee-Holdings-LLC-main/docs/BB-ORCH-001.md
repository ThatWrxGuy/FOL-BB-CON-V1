# BB-ORCH-001

Executive Intake & Recommendation Orchestration.

This flow routes a request through Malkuth → Yesod → Hod → Chokmah → Binah → Chesed → Gevurah → Tiferet → Malkuth and returns a structured recommendation packet.

Key characteristics:
- typed Fruit of Life contracts
- semantic Tree of Life node responsibilities
- Metatron Cube orchestration entrypoint
- product-ready response payload
