# Metatron Cube Overlay Integration

## What was added

This repository already contained a working `tree_engine/` based on the Tree of Life.
The new `metatron_cube/` folder wraps that engine with a second architectural layer.

- **Tree of Life stays the canonical execution spine**
- **Metatron Cube becomes the lateral mesh / topology overlay**

## Design principle

- `tree_engine/` answers: **what each node does and how execution flows vertically**
- `metatron_cube/` answers: **which nodes connect laterally and how the full network is traversed**

## New components

- `metatron_cube/node_registry.py` — reflects existing Tree nodes into a mesh registry
- `metatron_cube/connection_map.py` — explicit radial and lateral edges
- `metatron_cube/pathway_router.py` — shortest-path routing across the mesh
- `metatron_cube/event_mesh.py` — lightweight event bus for mesh-level transitions
- `metatron_cube/orchestration.py` — overlay coordinator that routes through the mesh and then executes the Tree
- `metatron_cube/api.py` — FastAPI endpoints for health, topology, and execution

## API endpoints

- `GET /metatron/health`
- `GET /metatron/topology`
- `POST /metatron/run`

## Execution model

1. User input enters **MetatronCore**
2. Overlay selects an entry node such as `Keter`, `Chokmah`, `Gevurah`, `Hod`, or `Yesod`
3. Mesh routing records the lateral trace
4. The existing `tree_engine` still executes the canonical Tree flow starting at `Keter`
5. Final output, confidence, explanation, and metrics are returned with both traces visible

## Why this is safe

This approach avoids destructive refactors.
It adds a real network layer without breaking the existing Tree-of-Life engine.
That makes it a strong bridge architecture for future repo evolution.
