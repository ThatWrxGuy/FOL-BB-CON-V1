from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class ExecutiveRequest:
    request_id: str
    user_id: str
    text: str
    channel: str = "api"
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DecisionContext:
    user_id: str
    profile: dict[str, Any]
    domain_data: dict[str, Any]
    goals: list[str]
    constraints: list[str]
    context_confidence: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RequestInterpretation:
    domain: str
    intent: str
    entities: dict[str, Any]
    primary_nodes: list[str]
    validation_nodes: list[str]
    final_node: str
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CandidateOption:
    option_id: str
    title: str
    summary: str
    assumptions: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ScoredOption:
    option: CandidateOption
    opportunity_score: float
    risk_score: float
    alignment_score: float = 0.5
    feasibility_score: float = 0.5
    blocked: bool = False
    notes: list[str] = field(default_factory=list)

    def final_score(self) -> float:
        return (
            0.35 * self.opportunity_score
            + 0.35 * self.alignment_score
            + 0.20 * self.feasibility_score
            - 0.30 * self.risk_score
        )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["final_score"] = self.final_score()
        return data


@dataclass
class FinalDecision:
    title: str
    summary: str
    rationale: list[str]
    risks: list[str]
    alternatives: list[dict[str, Any]]
    confidence: float
    next_steps: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class OrchestrationResponse:
    flow_id: str
    status: str
    decision: FinalDecision
    trace_id: str | None = None
    stage_trace: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "flow_id": self.flow_id,
            "status": self.status,
            "decision": self.decision.to_dict(),
            "trace_id": self.trace_id,
            "stage_trace": self.stage_trace,
        }
