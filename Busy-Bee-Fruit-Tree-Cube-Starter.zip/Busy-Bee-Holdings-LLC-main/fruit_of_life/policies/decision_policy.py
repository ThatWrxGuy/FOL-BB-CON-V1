from __future__ import annotations

from fruit_of_life.contracts.executive import DecisionContext, RequestInterpretation, ScoredOption


def apply_hard_stops(
    scored_options: list[ScoredOption],
    context: DecisionContext,
    interpretation: RequestInterpretation,
) -> list[ScoredOption]:
    for scored in scored_options:
        if context.context_confidence < 0.4:
            scored.notes.append("context confidence is low")
        if interpretation.confidence < 0.5:
            scored.notes.append("interpretation confidence is low")
        if scored.risk_score >= 0.9:
            scored.blocked = True
            scored.notes.append("blocked by risk threshold")
    return scored_options
