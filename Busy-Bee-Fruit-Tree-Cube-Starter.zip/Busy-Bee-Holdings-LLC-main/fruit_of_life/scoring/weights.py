def final_score(opportunity: float, alignment: float, feasibility: float, risk: float) -> float:
    return 0.35 * opportunity + 0.35 * alignment + 0.20 * feasibility - 0.30 * risk
