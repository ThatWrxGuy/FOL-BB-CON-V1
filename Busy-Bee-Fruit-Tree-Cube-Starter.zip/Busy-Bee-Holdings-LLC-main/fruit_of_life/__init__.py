"""Fruit of Life foundational primitives for Busy Bee."""
